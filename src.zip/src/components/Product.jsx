import React from 'react'





const Product = () => {
    const mystyle= {
      backgroundColor :'pink',
       margin :"10px",
       padding:"10px"

    }






  return (
    <div className='lorem'
    // style ={{
    // backgroundColor:'yellow',
    // color:"black"



    // }}
    style={mystyle}>Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptatum ducimus laboriosam molestias eaque fugit neque nostrum. Perspiciatis fugiat dolores voluptatem, ipsa explicabo amet consectetur accusamus esse ab illum obcaecati saepe.</div>
  )
}

export default Product