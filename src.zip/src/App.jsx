import React from 'react'
import Map from './components/Map'
import Conditional from './components/Conditional'
import Person from './components/Person'
import Counter from './components/Counter'
const App = () => {
// declartion of javascriopt
// const laptop =
// {
//     brandNAme: "hp",
//     price : 7000,
//     ram : "4 gb",
//     ssd: "250gb"
     


// }

// let phone ={
//  phonename : "Samsung"
  
   const dark=()=>{

     document.body.style.backgroundColor = "blue"
     document.body.style.color = "white"


   }
   const light =()=>
    {
       document.body.style.backgroundColor= "white"
       document.body.style.color = "black"




    }

  return (

    // <div>{
    //   laptop.brandNAme
      
    // }
    
    // <h1>{
    //   laptop.price
      
    // }</h1>
    // <h1>
    // {
    //   laptop.ram
      
    // }</h1>
    
    // </div>
    
    // <div>
    
    
    //  <h1>{
    //  phone.phonename



    //  }</h1>
    // <Product/>
    // <Product/>
    // <Product/>
    // </div>
    // <>
    // // <Conditional/>
    // <Person name =" Superman  " age = "  30 "  salary = "1000" img = " https://cdn.pixabay.com/photo/2023/03/15/10/14/hamburg-7854198_1280.jpg" />
    // <Person name =" spiderman  " age = "  30 "  salary = "1000" img="https://cdn.pixabay.com/photo/2013/03/02/02/41/alley-89197_640.jpg"/>
    // <Person name ="Batman " age = "  30 "  salary = "1000" img="https://cdn.pixabay.com/photo/2024/02/22/09/04/warehouse-8589487_640.jpg"/>
  
    // </>
    <>
     <button onMouseLeave={dark}> Dark </button>
    <button  onDoubleClick={light}> light</button>
    <Counter/>
    <Map/>
    </>
  )
}

export default App